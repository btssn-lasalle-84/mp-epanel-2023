# Epannel_2023
EPannel est un projet étudiant de BTS. Un panneau journal lumineux affichant des lieux dit qui tourne et pointe ces directions en cliquant sur un bouton d'une application WEB
